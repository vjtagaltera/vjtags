DC_FIFO design example using In-System Sources and Probes
==================================================================

The files contained in the archived Quartus II project, DC_FIFO.qar contains the 
design files.  The archived project directory contains Tcl/TK script, dc_fifo.tcl. This design example is developed using the Quartus II software version 7.1 using a Windows XP platform.

The design is targeted to a NIOS development kit, Stratix Edition (EP1S10).  


Useage flow:
==================================================================


1. Restore the archived project using the Quartus II software version 7.1 or later
2. Retarget the design to the specifications of your hardware.  
3. Compile and program your target hardware
4. Run quartus_stp shell using the command prompt by typing : quartus_stp -s
5. set the path to design directory of the DC_FIFO project.
6. Invoke the dc_fifo tcl script :  source dc_fifo.tcl
7. The project includes a Signal Tap II file, stp1.stp.
8. The project also includes a sources and Probes editor file, dc_fifo.spf which can be used to view and control the sources
   and probes instances within the design.  


The FIFO configured in the project is 8 bits wide x 16 words deep.


There is one sources and probes instance the controls the flow of data into the FIFO.  



The tcl script contains the following procedures:



start_fill  	:  control line that starts a pattern generator to perform a burst write into the fifo.
write <value> 	:  single word write from FIFO A side. Value is entered as hex or integer
read        	:  single word read from FIFO B side.  read value returned as a 10 bit binary string.  Most significant two 			   bits are the read empty flag and the read full flags, respectively.



