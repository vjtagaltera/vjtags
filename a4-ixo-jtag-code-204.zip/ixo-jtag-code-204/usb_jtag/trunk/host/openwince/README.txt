openwince jtag driver
=====================

This directory used to contain a patch for the openwince JTAG Tools,
available from http://openwince.sourceforge.net/jtag. However, in the
meantime a successor to the openwince tools evolved: UrJTAG.

UrJTAG, available from http://urjtag.org, has support for my adapter
and Altera USB-Blaster out of the box and doesn't need to be patched, 
while being similar in use and functionality to the openwince tools.

