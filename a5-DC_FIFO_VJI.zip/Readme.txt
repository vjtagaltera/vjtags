DC_FIFO design example using the Virtual JTAG Interface
==================================================================

The files contained in the archived Quartus II project, DC_FIFO_VJI.qar contains the 
design files.  The archived project directory contains Tcl/TK script, dc_fifo_vji.tcl. This design example is developed using the Quartus II software version 7.1 using a Windows XP platform.

The design is targeted to a NIOS development kit, Stratix Edition (EP1S10).  


Useage flow:
==================================================================


1. Restore the archived project using the Quartus II software version 7.1 or later
2. Retarget the design to the specifications of your hardware.  
3. Compile and program your target hardware
4. Run quartus_stp shell using the command prompt by typing : quartus_stp -s
5. set the path to design directory of the DC_FIFO_VJI project.
6. Invoke the dc_fifo_vji tcl script :  source dc_fifo_vji.tcl
7. The project includes a Signal Tap II file, stp1.stp.


The FIFO configured in the project is 8 bits wide x 16 words deep.
FIFO empty and FIFO full flags are not read back by VJI instance. (can be read via the attached SignalTap II file)


The tcl script contains the following procedures:



push <value>  :  single word write into FIFO A side.  value is an integer format less than 256.
pop   	      :  single word read from FIFO B side.   value is returned as a binary string.
flush         :  initiates a read burst transaction.  

